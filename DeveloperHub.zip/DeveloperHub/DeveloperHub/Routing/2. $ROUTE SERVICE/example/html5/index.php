<?php
$useHtml5Mode = true;

include("../common.php");
?>