<?php
$locData = array(
  "AngularJSLocaleFileName" => "angular-locale_it-it.js",
  "Index.textEdit" => "Scrivi qualcosa:",
  "Index.selectionCheck" => "Seleziona lo stato:",
  "Index.todaysDateStr" => "La data di oggi &egrave;",
  "Index.selectLanguageStr" => "Seleziona la lingua:",
  "Index.englishBtn" => "Inglese",
  "Index.italianBtn" => "Italiano"
);
?>