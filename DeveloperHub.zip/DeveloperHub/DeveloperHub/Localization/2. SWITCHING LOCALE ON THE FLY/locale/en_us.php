<?php
$locData = array(
  "AngularJSLocaleFileName" => "angular-locale_en-us.js",
  "Index.textEdit" => "Write something:",
  "Index.selectionCheck" => "Select the state:",
  "Index.todaysDateStr" => "Today's date is",
  "Index.selectLanguageStr" => "Select the language:",
  "Index.englishBtn" => "English",
  "Index.italianBtn" => "Italian"
);
?>